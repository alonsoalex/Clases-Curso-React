import React from 'react';

const ListContainer = (props) => {
  return (
    <div>{props.text}</div>
  )
}

export default ListContainer