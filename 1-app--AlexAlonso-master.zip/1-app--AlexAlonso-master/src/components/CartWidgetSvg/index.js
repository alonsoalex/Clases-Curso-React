import CartWidgetSvg from "../CartWidgetSvg/CartWidgetSvg";

export default CartWidgetSvg;